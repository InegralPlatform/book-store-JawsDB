<# if ( data.description ) { #>
	<span class="butterbean-description description">{{{ data.description }}}</span>
<# } #>
