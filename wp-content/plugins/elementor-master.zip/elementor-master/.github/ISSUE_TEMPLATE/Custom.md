---
name: "❓Support Question"
about: If you have a support question, please refer to our docs or our Facebook Elementor
  community. If this doesn’t look right, choose a different type.

---

- Please create GitHub issues only for bugs and feature requests. GitHub issues ARE NOT FOR SUPPORT!

- If you have questions or need general support,  Please use:  https://wordpress.org/support/plugin/elementor 

- For help and support from the Elementor community, see: https://www.facebook.com/groups/Elementors/

- To read more about Elementor, check out our documentation: https://docs.elementor.com

- Developers docs are located at: https://developers.elementor.com/
