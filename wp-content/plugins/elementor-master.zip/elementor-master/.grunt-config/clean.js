/**
 * Grunt clean task config
 * @package Elementor
 */
module.exports = {
	//Clean up build folder
	main: [
		'build'
	],
};
