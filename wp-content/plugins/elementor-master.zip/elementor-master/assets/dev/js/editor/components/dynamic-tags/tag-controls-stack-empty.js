module.exports = Marionette.ItemView.extend( {
	className: 'elementor-tag-controls-stack-empty',

	template: '#tmpl-elementor-tag-controls-stack-empty',
} );
