module.exports = elementorModules.editor.elements.models.BaseSettings.extend( {
	defaults: {
		_column_size: 100,
	},
} );
