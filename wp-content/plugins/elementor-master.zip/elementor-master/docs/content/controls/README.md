## Documentation has Moved

This document in now available on [Developer API for Elementor](developers.elementor.com)

### Quick Links

* [Getting Started](https://developers.elementor.com/getting-started/)
* [The Editor](https://developers.elementor.com/elementor-editor/)
* [The Widgets](https://developers.elementor.com/elementor-widgets/)
* [The Controls](https://developers.elementor.com/elementor-controls/)
* [Code Reference](https://code.elementor.com)
* [PHP Hooks](https://code.elementor.com/php-hooks/)
* [JS Hooks](https://code.elementor.com/js-hooks/)
* [Classes](https://code.elementor.com/classes/)
* [Methods](https://code.elementor.com/methods/)
* [Functions](https://code.elementor.com/functions/)