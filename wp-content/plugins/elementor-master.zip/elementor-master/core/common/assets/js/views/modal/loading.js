export default class extends Marionette.ItemView {
	id() {
		return 'elementor-template-library-loading';
	}

	getTemplate() {
		return '#tmpl-elementor-template-library-loading';
	}
}
